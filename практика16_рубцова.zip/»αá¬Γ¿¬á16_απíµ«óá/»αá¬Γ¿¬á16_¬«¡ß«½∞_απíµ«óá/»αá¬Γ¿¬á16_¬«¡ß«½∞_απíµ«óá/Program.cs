﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace практика16_консоль_рубцова
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (File.Exists("file1.txt"))
            {
                using (StreamWriter sw = new StreamWriter("file1.txt"))
                {
                    Console.WriteLine("Введите строку:");
                    string[] array = Console.ReadLine().Split(' ');
                    bool containSlash = array.Any(x => x.Contains("/"));
                    if (containSlash == true)
                    {
                        int digitcount = array.SelectMany(x => x).Count(char.IsDigit);
                        Console.WriteLine($"Количество цифр в массиве: {digitcount}");
                        Console.WriteLine("Элементы массива до символа '/':");
                        bool slash = false;
                        foreach (string s in array)
                        {
                            if (s.Contains("/"))
                            {
                                slash = true;
                                break;
                            }
                            Console.Write($"{s}");
                        }
                        Console.WriteLine("\nЭлементы массива после символа '/' с заменой регистра:");
                        var r = array.SkipWhile(x => x != "/")
                                               .Select(x => string.Concat(x.Select(c => char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c))))
                                               .ToArray();
                        foreach (var item in r)
                        {
                            Console.Write($"{item}");
                        }
                    }
                    else Console.WriteLine("В строке нет '/'!");
                    }
            }
            else Console.WriteLine("файл для записи не найден");
            Console.ReadKey();
        }
    }
}
