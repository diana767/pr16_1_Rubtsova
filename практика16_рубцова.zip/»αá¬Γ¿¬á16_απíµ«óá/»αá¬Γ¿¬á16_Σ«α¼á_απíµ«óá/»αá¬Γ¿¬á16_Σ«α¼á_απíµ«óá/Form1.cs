﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace практика16_форма_рубцова
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string stroka = "";
            if (File.Exists("file1.txt"))
            {
                StreamReader sr = File.OpenText("file1.txt");
                while (!sr.EndOfStream)
                {
                    stroka = sr.ReadLine();
                    listBox1.Items.Add("из файла:");
                    listBox1.Items.Add(stroka);
                }
                sr.Close();
                string word = textBox1.Text.ToLower();
                if (word == "" || word == " ")
                { MessageBox.Show("вы неправильно ввели слово", "error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                else
                {
                    int count = stroka.ToLower().Split(' ', ',', '.').Count(s => s == word);
                    listBox1.Items.Add($"были найдены {count} вхождения(ий) поискового запроса '{word}' ");
                }
            }
            else MessageBox.Show("файл не найден", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
